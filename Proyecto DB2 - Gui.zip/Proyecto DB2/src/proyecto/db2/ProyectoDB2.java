/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto.db2;

/**
 *
 * @author HTS
 */
public class ProyectoDB2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LogIn l = new LogIn();
        l.setVisible(true);
        // TODO code application logic here
    }
    
}
